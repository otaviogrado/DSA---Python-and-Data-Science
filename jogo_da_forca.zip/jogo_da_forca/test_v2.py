# BIBLIOTECAS
import random


# FUNÇÕES AUXILIARES
def impressao_palavra(palavra, tam):
    for i in range(tam):                            # mostra ao usuário a palavra
        print(palavra[i], end=' ')
    print()

def impressao_forca(chances):
    print(board[abs(chances-6)])

def interface(chances, tam, secreta):
    impressao_forca(chances)
    print(f'O numero de chances é:\t{chances}\n')
    impressao_palavra(secreta, tam)

def status(acertos, tam, chances):
    if (acertos == tam):
        print('\nVitória!! A palavra é:')
        impressao_palavra(palavra, tam)

    if(chances == 0):
        impressao_forca(chances)
        print('\nDerrota!! A palavra era:')
        impressao_palavra(palavra, tam)

def rand_word():
    with open('palavras.txt', 'rt') as f:
        bank = f.readlines()
    return  bank[random.randint(0, len(bank))].strip()

# INICIALIZAÇÃO DAS VARIÁVEIS
chances = 6
tam = 0
acerto = False
acertos = 0

palavra = rand_word()
tam = len(palavra)
secreta = tam * [0]

for i in range(tam):                # configuração para o usuário da palavra a ser revelada
    secreta[i] = '_'

board = ['''
>>>>>>>>>>>>>>>>>>HANGMAN <<<<<<<<<<<<<<<<<<<

+-----+
|     |
      |
      |
      |
      |
************''', '''

 +-----+
 |     |
 0     |
       |
       |
       |
************''', '''

 +-----+
 |     |
 0     |
 |     |
       |
       |
************''', '''

 +-----+
 |     |
 0     |
/|     |
       |
       |
************''', '''

 +-----+
 |     |
 0     |
/|\    |
       |
       |
************''', '''

 +-----+
 |     |
 0     |
/|\    |
/      |
       |
************''', '''

 +-----+
 |     |
 0     |
/|\    |
/ \    |
       |
************''']


# JOGO
while(acertos < tam and chances > 0):

    interface(chances, tam, secreta)                # status do jogo
    letra = input('Entre com a letra:\t')           # usuário entra com a letra
    letra = letra.lower()

    for j in range(tam):                            # loop for para contabilizar acertos e colocar a letra na palavra secreta
        if(palavra[j] == letra):
            acerto = True
            secreta[j] = palavra[j]
            acertos = acertos+1

    if (acerto == False):                           # diminui as chances caso o usuário erra a letra
        chances = chances-1

    acerto = False
    status(acertos, tam, chances)